"use strict";

{
    console.log('hello luna');
}